import 'package:aspends_tracker/core/const/app_assets.dart';
import 'package:aspends_tracker/core/models/transaction.dart';
import 'package:flutter/material.dart'; 

class TransactionUtils {
  static String getCategorySvg(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return SvgAppIcons.foodIcon;
      case 'transport':
        return SvgAppIcons.transportIcon;
      case 'flipkart':
        return SvgAppIcons.shoppingIcon;
      case 'shopping':
        return SvgAppIcons.shoppingIcon;
      case 'amazon':
        return SvgAppIcons.shoppingIcon;
      case 'education':
        return SvgAppIcons.educationIcon;
      case 'groceries':
        return SvgAppIcons.groceriesIcon;
      case 'charity':
      case 'carity':
        return SvgAppIcons.charityIcon;
      case 'loan repayment':
        return SvgAppIcons.loanRepaymentIcon;
      case 'loan':
        return SvgAppIcons.loanIcon;
      case 'other':
        return SvgAppIcons.otherIcon;
      case 'freelance':
        return SvgAppIcons.freelanceIcon;
      case 'gift':
        return SvgAppIcons.giftIcon;
      case 'cashback':
        return SvgAppIcons.cashbackIcon;
      case 'business':
        return SvgAppIcons.businessIcon;
      case 'bills':
        return SvgAppIcons.billIcon;
      case 'entertainment':
        return SvgAppIcons.entertainmentIcon;
      case 'health':
        return SvgAppIcons.healthIcon;
      case 'gift':
      case 'gifts':
        return SvgAppIcons.giftIcon;
      case 'bonus':
        return SvgAppIcons.giftIcon;
      case 'fuel':
        return SvgAppIcons.fuelIcon;
      case 'rent':
      case 'rent received':
        return SvgAppIcons.rentIcon;
      case 'travel':
      case 'uber':
      case 'ola':
        return SvgAppIcons.travelIcon;
      case 'maintenance':
        return SvgAppIcons.maintenanceIcon;
      case 'insurance':
        return SvgAppIcons.insuranceIcon;
      case 'subscription':
        return SvgAppIcons.subscriptionIcon;
      case 'personal care':
        return SvgAppIcons.personalCareIcon;
      case 'tax':
        return SvgAppIcons.taxIcon;
      case 'salary':
        return SvgAppIcons.salaryIcon;
      case 'investment':
        return SvgAppIcons.investmentIcon;
      case 'income':
        return SvgAppIcons.incomeIcon;
      case 'interest':
        return SvgAppIcons.interestIcon;
      case 'refund':
        return SvgAppIcons.refundIcon;
      default:
        return SvgAppIcons.genericCategoryIcon;
    }
  }

  static Map<String, List<Transaction>> groupTransactionsByDate(
      List<Transaction> txns) {
    final Map<String, List<Transaction>> grouped = {};
    // Respect input order (pre-sorted by ViewModel)
    final sortedTxns = txns;

    for (final tx in sortedTxns) {
      final dateKey =
          "${tx.date.year}-${tx.date.month.toString().padLeft(2, '0')}-${tx.date.day.toString().padLeft(2, '0')}";
      grouped.putIfAbsent(dateKey, () => []).add(tx);
    }
    return grouped;
  }

  static String formatRelativeDate(String dateKey) {
    try {
      final parts = dateKey.split('-');
      if (parts.length != 3) return dateKey;

      final date = DateTime(
          int.parse(parts[0]), int.parse(parts[1]), int.parse(parts[2]));
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final yesterday = today.subtract(const Duration(days: 1));

      if (date.isAtSameMomentAs(today)) {
        return 'Today';
      } else if (date.isAtSameMomentAs(yesterday)) {
        return 'Yesterday';
      }

      // For other dates, use simple formatting or just return the key if preferred
      // But let's make it look nicer: "Feb 09, 2026"
      const months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec'
      ];
      return "${months[date.month - 1]} ${date.day.toString().padLeft(2, '0')}, ${date.year}";
    } catch (e) {
      return dateKey;
    }
  }

  static IconData getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return Icons.restaurant;
      case 'transport':
        return Icons.directions_bus;
      case 'shopping':
        return Icons.shopping_bag;
      case 'bills':
        return Icons.receipt_long;
      case 'entertainment':
        return Icons.movie;
      case 'health':
        return Icons.medical_services;
      case 'education':
        return Icons.school;
      case 'salary':
        return Icons.payments;
      case 'freelance':
        return Icons.work;
      case 'investment':
        return Icons.trending_up;
      case 'gift':
        return Icons.card_giftcard;
      case 'refund':
        return Icons.replay;
      case 'bank transaction':
      case 'hdfc bank':
      case 'state bank of india':
      case 'icici bank':
      case 'axis bank':
      case 'pnb':
      case 'bank':
        return Icons.account_balance;
      case 'paytm':
      case 'phonepe':
      case 'google pay':
      case 'gpay':
      case 'amazon pay':
      case 'upi':
        return Icons.account_balance_wallet;
      case 'zomato':
      case 'swiggy':
        return Icons.fastfood;
      case 'amazon':
      case 'flipkart':
        return Icons.shopping_cart;
      case 'uber':
      case 'ola':
        return Icons.local_taxi;
      case 'groceries':
        return Icons.shopping_basket;
      case 'fuel':
        return Icons.local_gas_station;
      case 'rent':
      case 'rent received':
        return Icons.home;
      case 'travel':
        return Icons.flight;
      case 'maintenance':
        return Icons.settings;
      case 'insurance':
        return Icons.security;
      case 'subscription':
        return Icons.subscriptions;
      case 'personal care':
        return Icons.face;
      case 'tax':
        return Icons.gavel;
      case 'charity':
        return Icons.favorite;
      case 'loan repayment':
        return Icons.credit_score;
      case 'bonus':
        return Icons.card_giftcard;
      case 'interest':
        return Icons.account_balance_wallet;
      case 'cashback':
        return Icons.account_balance_wallet;
      case 'business':
        return Icons.business_center;
      default:
        return Icons.category;
    }
  }

  static Color getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return Colors.orange;
      case 'transport':
        return Colors.blue;
      case 'shopping':
        return Colors.purple;
      case 'bills':
        return Colors.red;
      case 'entertainment':
        return Colors.pink;
      case 'health':
        return Colors.green;
      case 'education':
        return Colors.indigo;
      case 'salary':
        return Colors.teal;
      case 'freelance':
        return Colors.amber;
      case 'investment':
        return Colors.cyan;
      case 'gift':
        return Colors.deepOrange;
      case 'refund':
        return Colors.lightGreen;
      case 'hdfc bank':
      case 'icici bank':
      case 'axis bank':
        return Colors.blue.shade800;
      case 'paytm':
        return Colors.lightBlue;
      case 'google pay':
      case 'gpay':
        return Colors.blueAccent;
      case 'phonepe':
        return Colors.deepPurple;
      case 'zomato':
        return Colors.redAccent;
      case 'swiggy':
        return Colors.orangeAccent;
      case 'groceries':
        return Colors.lightGreen;
      case 'fuel':
        return Colors.amber;
      case 'rent':
      case 'rent received':
        return Colors.blueGrey;
      case 'travel':
        return Colors.cyan;
      case 'maintenance':
        return Colors.brown;
      case 'insurance':
        return Colors.blueAccent;
      case 'subscription':
        return Colors.redAccent;
      case 'personal care':
        return Colors.pinkAccent;
      case 'tax':
        return Colors.deepPurple;
      case 'charity':
        return Colors.red;
      case 'loan repayment':
        return Colors.blue;
      case 'bonus':
        return Colors.amber;
      case 'interest':
        return Colors.indigo;
      case 'cashback':
        return Colors.lightBlue;
      case 'business':
        return Colors.deepOrange;
      default:
        return Colors.grey;
    }
  }

  static IconData getAccountIcon(String account) {
    switch (account.toLowerCase()) {
      case 'cash':
        return Icons.money;
      case 'online':
        return Icons.account_balance;
      case 'credit card':
        return Icons.credit_card;
      case 'bank':
        return Icons.account_balance;
      case 'savings':
        return Icons.savings;
      case 'wallet':
        return Icons.account_balance_wallet;
      case 'upi':
        return Icons
            .pix; // Pix is similar to UPI icon in some contexts, but let's use account_balance_wallet or similar
      case 'debit card':
        return Icons.credit_card;
      default:
        return Icons.wallet;
    }
  }

  static (DateTime, DateTime) getDateRange(String range) {
    final now = DateTime.now();
    DateTime startDate;
    DateTime endDate = now;

    if (range == 'Day') {
      startDate = DateTime(now.year, now.month, now.day);
    } else if (range == 'Week') {
      startDate = now.subtract(Duration(days: now.weekday - 1));
      startDate = DateTime(startDate.year, startDate.month, startDate.day);
    } else if (range == 'Month') {
      startDate = DateTime(now.year, now.month, 1);
    } else if (range == 'Year') {
      startDate = DateTime(now.year, 1, 1);
    } else {
      startDate = DateTime(2000);
    }
    return (startDate, endDate);
  }
}
